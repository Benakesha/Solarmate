<?php
  include_once('navigation.php');
?>


<!--<div class="container-fluid">
	<div class="row">
		<div class="col-md-12 wow slideInLeft">
			<?php
				include_once('footer.php');
			?>
		</div>
	</div>
</div>
-->