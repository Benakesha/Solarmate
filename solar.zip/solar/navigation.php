<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<!-- Font Awesome -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- Bootstrap core CSS -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.14/css/mdb.min.css" rel="stylesheet">
	<!--<link rel="stylesheet" type="text/css" href="css/navigation.css">-->
	<link rel="stylesheet" type="text/css" href="css/navigation.css">
</head>
<body >
  <div class="container-fluid" >
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12">
        <!--Navbar-->
        <nav class="navbar navbar-expand-lg navbar-dark cyan fixed-top">

          <!-- Navbar brand -->
          <a class="navbar-brand" href="index.php" style="margin-top: -10px;padding-top: -5px;margin-bottom: -5px;"><img class="imgbrand" src="images/logo.jpg" width="150" height="80" style="margin-bottom: -5px;"></a>

          <!-- Collapse button -->
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
            aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <!-- Collapsible content -->
          <div class="collapse navbar-collapse" id="basicExampleNav">

            <!-- Links -->
            <ul class="navbar-nav mr-auto">
              <li class="nav-item active">
                <a class="nav-link" href="index.php">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.php">About&nbsp;&nbsp;&nbsp;</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="ourTeam.php">Our Team&nbsp;&nbsp;&nbsp;</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="calculator.php">Calculator&nbsp;&nbsp;&nbsp;</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="userStories.php">User Stories&nbsp;&nbsp;&nbsp;</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="blogs.php">Blogs&nbsp;&nbsp;&nbsp;</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="faq.php">FAQs</a>
              </li>
            </ul>
            <!-- Links -->

            <span class="navbar-text white-text">
              <a class="nav-link" href="http://www.installer.enermate.in">For Installers&nbsp;&nbsp;</a>
            </span>
          </div>
          <!-- Collapsible content -->

        </nav>
        <!--/.Navbar-->    
      </div>
    </div>
  </div>




<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.14/js/mdb.min.js"></script>

</body>
</html>