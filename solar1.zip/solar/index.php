<?php
  include_once('navigation.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Home | Solatmate</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- Bootstrap core CSS -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.5.14/css/mdb.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/indexStyle.css">
	<link rel="shortcut icon" type="image/png" href="images/favicon.png"/>
	
</head>
<body>
	<div class="container-fluid image" >
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<img src="images/solar.png" class="animated zoomIn image1" style="height:auto; width: 100%; object-fit: contain"/> 
				<p class="p1 animated zoomIn">
					<span>Solar Energy for your Home and Business</span><span class="spacer">
						
					</span>
				</p>
				<p class="p2 animated zoomIn">
					<span>Smart Design. Easy Finance. </span><span class="spacer"></span>
				</p>
			</div>
		</div>
	</div>
	<div class="container-fluid" style="margin-top:1%;margin-bottom: 2%;">
		<div class="row" id="firstDiv">
			<div class="col-md-12">  
				<div class="card cone wow fadeInUp" >
					<div class="card-body">
				   		<p class="card-title p3 wow fadeInUp"><a>Easy Financing</a></p>
				   		<p class="p4 wow fadeInUp">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
				   
				   		<ul class="card-list wow fadeInUp" style="list-style-type: none;float: left;"> 
				   			<li> 
				   				<h4><i class="fa fa-sun-o"></i>Solar system design</h4>
				   				<p id="p5">Solarmate provides multiple system options. Choose your final design and price.</p>
				   			</li>
				   			<li> 
				   				<h4><i class="fa fa-book"></i>KYC process</h4>
				   				<p id="p5">Email your documents to Solarmate for quick verification.</p>
				   			</li>	
				   			<li> 
				   				<h4><i class="fa fa-university"></i>Solarmate bank partnerships (IDBI, SIDBI and others)</h4>
				   				<p id="p5">Solarmate works with multiple banks simultaneously to identify financing that's perfect for you.</p>
				    			</li>
				    			<li> 
				   				<h4><i class="fa fa-handshake-o"></i>Financing done!</h4>
				   				<p id="p5">Loans are typically disbursed in 3-4 weeks.</p>
				   			</li>
				   		</ul> 
				   		<ul class="banker" style="float: left;list-style-type: none;">
				   			<li>
								<img class="wow fadeInUp" src="images/idbi.jpg" width="300" height="150" />
							</li>
							<li>
								<img class="wow fadeInUp" src="images/sidbi.jpg" width="300" height="150"/>
							</li>
				   		</ul>
				   	</div>
				</div>
			</div>
		</div>	
	</div>

	<div class="container-fluid" style="margin-bottom: 2%;">
		<div class="row" id="secondDiv">
			<div class="col-md-12">
				<h2 class="wow fadeInUp h2l" style="text-align: center;color: #00BCD4;margin-bottom: 2%; ">LOAN TERMS</h2>
				<div class="col-md-6 card1">
					<div class="card wow fadeInUp">
						<div class="card-body">
							<p class="card-title p7">For Individuals</p>
							<h5>*&nbsp;Loan Amount Limits</h5>
							<ul class="ul1" style="list-style-type: none;">
								
								<li>Up to ₹25 Lakh or 85% of project cost (whichever is lower)</li>
							</ul>
							<h5>*&nbsp;Interest Rate</h5>
							<ul class="ul2" style="list-style-type: none;">
								<li>Home loan top up: 9%</li>
								<li>General: 10.65%</li>
								<li>Women: 10.15%</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-6 card2">
					<div class="card wow fadeInUp">
						<div class="card-body">
							<p class="card-title p7">For Commercial Sites, Factories, Colleges or Hospitals</p>
							<h5>*&nbsp;Loan Amount Limits</h5>
							<ul class="ul1" style="list-style-type: none;">
								<li>Up to ₹1.5 Crore or 80% of project cost (whichever is lower)</li>
							</ul>
							<h5>*&nbsp;Interest Rate</h5>
							<ul class="ul2" style="list-style-type: none;padding-bottom: 20px;">
								<li>Upto ₹25 Lakh: 10.65%</li>
								<li>More than ₹25 Lakh: 9.5%</li>
							</ul>
						</div>
					</div>
				</div>

			</div>
		</div>
		<div class="row" style="margin-top: 2%;">
			<div class="col-md-12">	
				<div class="col-md-6 card3" >
					<div class="card wow fadeInUp">
						<div class="card-body">
						<p class="card-title p7">For Housing Societies</p>
						<h5>*&nbsp;Loan Amount Limits</h5>
							<ul class="ul1" style="list-style-type: none;">
								
								<li>Up to ₹1.5 Crore or 80% of project cost (whichever is lower)</li>
							</ul>
							<h5>*&nbsp;Interest Rate</h5>
							<ul class="ul2" style="list-style-type: none;padding-bottom: 190px;">
								<li>General: 10.65%</li>
								
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-6 card4">
					<div class="card wow fadeInUp" >
						<div class="card-body" >
							<p class="card-title p7">For all categories</p>
							<h5>*&nbsp;Loan duration</h5>
							<ul class="ul1" style="list-style-type: none;">
								<li>Up to 7 years</li>
							</ul>
							<h5>*&nbsp;Loan processing time needed</h5>
							<ul class="ul2" style="list-style-type: none;">
								<li>Typically 3-4 weeks</li>
							</ul>
							<h5>*&nbsp;Loan processing charges</h5>
							<ul class="ul3" style="list-style-type: none;">
								<li>Up to ₹1 Lakh: Free!</li>
								<li>Above ₹1 Lakh: From 0.50% of loan amount</li>
							</ul>
							<h5>*&nbsp;Insurance Requirements</h5>
							<ul class="ul4" style="list-style-type: none;">
								<li>Solar assets created with such bank loans need to be insured in favour of the bank for the duration of the loan</li>
							</ul>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid" style="margin-left: 13px; padding-right: 30px;">
		<div class="row" id="thirdDiv">
			<div class="col-md-12">
				<h2 class="wow fadeInUp h2p" style="text-align: center;color: #00BCD4;margin-bottom: 2%;margin-top: 1%; ">LOAN PROCESS</h2>
				<div class="card card6 wow fadeInUp">
					<div class="card-body">
						<h4 class="card-title wow fadeInUp" >What is the process for a solar loan application?</h4>
						<p>At the time of the site visit, please provide the following documents:</p>
						<ul style="list-style-type: none;text-align: center;">
							<li  class="wow rollIn li1" style="float: left;margin-right: 5%;margin-left: 10%;color: mediumorchid">1. PAN Card</li>

							<li  class="wow rollIn li2" style="float: left; margin-right: 5%;color: mediumorchid">2. Proof of Identity</li>

							<li  class="wow rollIn li3" style="float: left;color: mediumorchid">3. Proof of Address</li>
							<br>
						</ul>
						<br>
						<p class="p9">We will match your requirements across our bank and lender partners to find the best loan for you, guide you through the KYC process, and facilitate the approval process so your installation work can start at the earliest.</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="container-fluid" style="margin-top: 2%;margin-left: 13px;padding-right: 30px;margin-bottom: 2%;">
		<div class="row" id="fourthDiv">
			<div class="col-md-12">
				<h2 class="wow fadeInUp h2i" style="text-align: center;color: #00BCD4;margin-bottom: 2%;margin-top: 1%;  ">INSTALLATION PROCESS</h2>
				<div class="card card7 wow fadeInUp">
					<div class="card-body">
						<h4 class="card-title wow fadeInUp">No Stress Installation</h4>	
						<p class="wow fadeInUp" style="margin-left: 20px;">Single point of contact during design, on-site work, and net-metering</p>
						<ul class="nav nav-tabs wow fadeInUp tabnav" id="myTab" role="tablist">
						  <li class="nav-item">
						    <a class="nav-link active" id="Design-tab" data-toggle="tab" href="#Design" role="tab" aria-controls="Design" aria-selected="true">Detailed Design</a>
						  </li>
						  <li class="nav-item">
						    <a class="nav-link" id="Work-tab" data-toggle="tab" href="#Work" role="tab" aria-controls="Work" aria-selected="false">On-Site Work</a>
						  </li>
						  <li class="nav-item">
						    <a class="nav-link" id="Metering-tab" data-toggle="tab" href="#Metering" role="tab" aria-controls="Metering" aria-selected="false">Net Metering</a>
						  </li>
						</ul>
						<div class="tab-content" id="myTabContent">
							<div class="tab-pane show active wow fadeInUp" id="Design" role="tabpanel" aria-labelledby="Design-tab">
								<ul style="list-style-type: none;float: left;">
									<li>
										<img class="wow fadeInUp" src="images/design.jpg">
									</li>
								</ul>
								<ul class="ul4 wow fadeInUp" style="list-style-type: none;float: left;">
									<li><i class="fa fa-desktop"></i>Solarmate designs multiple system options for you (e.g. Premium, Economy).
									<li><i class="fa fa-paint-brush"></i>Based on your selection, Solarmate creates a final system design.</li>
									<li><i class="fa fa-file-text"></i>Solarmate provides detailed guidance to help you make this choice.	</li>
								</ul>
							</div>
							<div class="tab-pane" id="Work" role="tabpanel" aria-labelledby="Work-tab">
							  	<ul style="list-style-type: none;float: left;">
									<li>
										<img class="wow fadeInUp" src="images/sitework.jpg">
									</li>
								</ul>
								<ul class="ul4 wow fadeInUp" style="list-style-type: none;float: left;">
									<li><i class="fa fa-truck"></i>Encompasses delivery, construction and commissioning of your solar installation.
									<li><i class="fa fa-group"></i>Your presence is needed only during this installation phase.</li>
									<li><i class="fa fa-calendar-check-o"></i>Systems less than 20kW are typically completed within 7 days.</li>
								</ul>
							</div>
							<div class="tab-pane" id="Metering" role="tabpanel" aria-labelledby="Metering-tab">
								<ul style="list-style-type: none;float: left;">
									<li>
										<img id="netgif" class="wow fadeInUp" src="images/netmeter.gif">
									</li>
								</ul>
								<ul class="ul4 ul5 wow fadeInUp">
									<li><i class="fa fa-plug"></i>Net Metering (NM) allows you to seamlessly push electricity from your solar energy system into the main power grid. As a result, you get the benefits of near-zero bills and low carbon footprint.</li>
									<li><i class="fa fa-book"></i>To get a NM connection, technical approval and an updated (bi-directional) meter is needed from your local electricity office.</li>
									<li><i class="fa fa-check-square-o"></i>Don’t worry, Solarmate takes care of this from start to finish!</li> 
									
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 wow fadeInUp">
				<?php
					include_once('footer.php');
				?>
			</div>
		</div>
	</div>
	 

</body>
<script type="text/javascript">
	new WOW().init();
</script>
</html>
