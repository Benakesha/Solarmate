<?php
  include_once('navigation.php');
?>
<link rel="stylesheet" type="text/css" href="css/calculator.css">
<div class="container-fluid" style="margin-top: 10%;">
	<div class="row">
		<div class="col-md-12">
			<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="card card1">
					<div class="card-body">
						<h3>Let's Design Your System&nbsp;&nbsp;&nbsp;<img src="images/sun.png" width="50" height="50"></h3>
						<form class="" method="POST" action="#">
							<div class="md-form">
								<input type="text" name="pincode" id="pincode" class="form-control">
								<label for="pincode">PIN CODE</label>
							</div>
							<div class="md-form">
								<input type="number" name="area" id="area" class="form-control">
								<label for="area">Roof Area (Sqft)</label>
							</div>
							<div class="md-form">
								<input type="number" name="bill" id="bill" class="form-control">
								<label for="bill">Average Monthly Electricity Bill(Rs)</label>
							</div>
							<div class="md-form">
								<select class="custom-select form-control" id="electType">
									<option value="" disabled selected>Choose Electricity Connection Type</option>
									<option value="Res">Recidential</option>
									<option value="Com">Commercial</option>
									<option value="Hou">Housing Society</option>
								</select>
							</div>
							<div class="md-form">
								<select class="custom-select form-control" id="electProvider">
									<option value="" disabled selected>Choose Electricity Provider</option>
									<option value="Ban">Bangalore Electricity Supply Company Ltd.(BESCOM)</option>
									<option value="Man">Mangalore Electricity Supply Company Ltd.(MESCOM)</option>
									<option value="Hub">Hubli Electricity Supply Company Ltd.(HESCOM)</option>
									<option value="Gul">Gulbarga Electricity Supply Company Ltd.(GESCOM)</option>
									<option value="Cha">Chamundeshwari Electricity Supply Company Ltd.(CESCOM)</option>
								</select>
							</div>
							<div class="md-form">
								<button type="submit" class="btn btn-warning waves-effect btn-lg" id="design" name="design">DESIGN</button>
							</div>
						</form>
					</div>
				</div>
			</div>
	
		</div>
	</div>
</div>