<?php
  include_once('navigation.php');
?>
<link rel="stylesheet" type="text/css" href="css/about.css">
<div class="container-fluid mainContainer">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-md-12 cpl-sm-12">
			<div class="card mainCard">
				<div class="card-body">
					<h4 class="animated zoomIn">Why Solarmate</h4>
					<p class="p1 animated zoomIn">Thousands of people in India are turning to solar energy to power their houses, factories and workplaces. Are you one of them?</p>

					<p class="p2 animated zoomIn">Our platform brings the best of solar technology, data and financing under Solarmate brand to help you join the solar revolution.</p>
					<div class="row">
						<div class="col-lg-12 col-md-12 col-md-12 cpl-sm-12">
							<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12 card1">
								<div class="card animated zoomIn">
									<div class="card-header purple-gradient">
										<h5>The Best Brand at Low Price <i class="fa fa-inr"></i></h5>
									</div>
									<div class="card-body">
										<p>Solarmate directly partners with the best solar brands in India and globally to get volume discounts and pass them on to you.</p>

										<p>This along with Solarmate's design algorithms, provides high efficiency system designs at low prices.</p>
									</div>
								</div>
							</div>
							<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12 card2">
								<div class="card animated zoomIn">
									<div class="card-header purple-gradient">
										<h5>Easy financing<i class="fa fa-university"></i></h5>
									</div>
									<div class="card-body">
										<p>Solarmate has direct agreements with nationalised banks to provide low interest loans for homes, housing societies, businesses and non-profit institutions.</p>

										<p>We work with private foreign investors to provide PPA financing to industrial customers.</p>
									</div>
								</div>
							</div>
							<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12 card3">
								<div class="card animated zoomIn">
									<div class="card-header purple-gradient">
										<h5>Smart customer support<i class="fa fa-desktop"></i></h5>
									</div>
									<div class="card-body">
										<p>Get live data from your system, maintenance alerts and notifications on your Solarmate app.</p>

										<p>Need some help with the system? Call Solarmate directly from the app, and we will promptly send a verified technician.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	

	<div class="row">
		<div class="col-lg-12 col-md-12 col-md-12 cpl-sm-12">
			<div class="card secondCard">
				<div class="card-body wow zoomIn">
					<h4 >About Us</h4>
							<p>Cleantech + Financing + IoT technologies = A million solar roofs!</p>
							<p>India’s rooftop solar market is exploding: India added more solar capacity in 2016 than all previous years combined. The Indian government has an ambitious target of 100GW (~USD 100 Billion) solar capacity deployed by 2022, out of which 40% is rooftop. Costs have decreased and policies are favorable, but average homeowners, business-owners, non-profit administrators or housing societies all face a very frictionful experience when they try to explore solar as a solution.</p>

							<p>This is the problem we are solving at Solarmate. We make it easy for people to save money while doing good for the environment.</p>

							<p>Today, Solarmate is one of the most innovative and fastest growing platforms for rooftop solar in India.</p>
							
							
				</div>
			</div>	
		</div>
	</div>

	<div class="row">
		<div class="col-lg-12 col-md-12 col-md-12 cpl-sm-12">
			<div class="card thirdCard">
				<div class="card-body  wow zoomIn">
					<h4>Solarmate Technology</h4>
							<p>Making the solar adoption process easy... is not easy, and we are hard at work leveraging technology to help solve this.</p>
							
							<h5>Data-driven solar calculators</h5>

							<p>Our customers get instant solar quotes for different system sizes, and multiple price options and financing rates. Beneath the surface, we use complex algorithms driven by geospatial info, weather APIs, solar irradiation data and customer electricity consumption. These tools enable our customers to make informed decisions on solar quickly.</p>

							<h5>IoT tech stack for Solar Monitoring</h5>

							<p>Solarmate monitoring allows customers to keep an eye on their system's performance, get notifications regarding regular maintenance, and spread the word, by sharing their savings data with friends and family. Our monitoring solution is powered by an integrated tech stack including battery-efficient hardware, high-performance time-series databases, and Solarmate's iOS and Android frontends. All this solar data is fed back to our engine, thus improving our solar recommendation algorithms.</p>

							<p>We continue to refine these core technologies, while an excellent response from our customers and backing of some amazing investors has put us on course for something special.</p>
				</div>
			</div>	
		</div>
	</div>

	<div class="row">
		<div class="col-lg-12 col-md-12 col-md-12 cpl-sm-12">
			<div class="card fourthCard">
				<div class="card-body">
					<h4 class="wow zoomIn">Our Team</h4>
					<div class="row">
						<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
							<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 " style="float: left;">
								<div class="card wow zoomIn">
									<div class="card-body">
										<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12 view overlay zoom" style="float: left;">
											<img src="images/benakesh.jpg" class="img-fluid rounded-circle wow zoomIn" alt="1" width="130" height="20"/>
										</div>
										<div class="col-md-8 col-lg-8 col-sm-12 col-xs-12"  style="float: left;">
											<h3>&nbsp;Benakesha N</h3>
											<h5>Software Engineer</h5>
										</div>
										<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12" style="margin-top: 40%;" >
											<p>Breathes  Material Design, PHP</p>
											<p>Full-stack developer at <b>Enermate Energy Pvt Ltd.</b>, Bangalore.</p>
										
											<p>Don't like this website? He's responsible for it.</p>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="float: left;">
								<div class="card wow zoomIn">
									<div class="card-body">
										<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12 view overlay zoom" style="float: left;">
											<img src="images/benakesh.jpg" class="img-fluid rounded-circle wow zoomIn " alt="1" width="130" height="20"/>
										</div>
										<div class="col-md-8 col-lg-8 col-sm-12 col-xs-12"  style="float: left;">
											<h3>&nbsp;Benakesha N</h3>
											<h5>Software Engineer</h5>
										</div>
										<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12" style="margin-top: 40%;" >
											<p>Breathes  Material Design, PHP</p>
											<p>Full-stack developer at <b>Enermate Energy Pvt Ltd.</b>, Bangalore.</p>
										
											<p>Don't like this website? He's responsible for it.</p>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="float: left;">
								<div class="card wow zoomIn">
									<div class="card-body">
										<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12 view overlay zoom" style="float: left;">
											<img src="images/benakesh.jpg" class="img-fluid rounded-circle wow zoomIn" alt="1" width="130" height="20"/>
										</div>
										<div class="col-md-8 col-lg-8 col-sm-12 col-xs-12"  style="float: left;">
											<h3>&nbsp;Benakesha N</h3>
											<h5>Software Engineer</h5>
										</div>
										<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12" style="margin-top: 40%;" >
											<p>Breathes  Material Design, PHP</p>
											<p>Full-stack developer at <b>Enermate Energy Pvt Ltd.</b>, Bangalore.</p>
										
											<p>Don't like this website? He's responsible for it.</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-12	">
			<?php
				include_once('footer.php');
			?>
		</div>
	</div>
</div>
<script type="text/javascript">
	new WOW().init();
</script>