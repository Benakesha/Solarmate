<?php
  include_once('navigation.php');
?>
<link rel="stylesheet" type="text/css" href="css/faq.css">
<div class="container-fluid" id="mainDiv">
	<div class="row">
		<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
			<div class="card card1" >
				<div class="card-body">
					<h3>Frequently Asked Questions<i class="fa fa-commenting"></i></h3>
					<ul class="nav nav-tabs" id="myTab" role="tablist">
						<li class="nav-item">
						   <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Installation</a>
						</li>
						<li class="nav-item">
						   <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Financing</a>
						</li>
						<li class="nav-item">
						   <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Maintenance</a>
						</li>
					</ul>
					<div class="tab-content" id="myTabContent">
					  	<div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
					  		<div class="accordion" id="accordionExample">
								<div class="card card2 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								    	<h5 class="mb-0">
									        <button class="btn btn-link" type="button" >
									         What are the steps involed in installation ?
									        </button>
									        <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
								    	<div class="card-body">
								      		<ul style="list-style-type: none;">
								      			Typically, a rooftop installation involves the following steps:
								      			<br>
												<li>1. Site visit to understand location and the project details.</li>

												<li>2. Providing multiple installation options to customer.</li>

												<li>3. Close on final system design and cost with customer.</li>

												<li>4. Deliver all installation material at the site.</li>

												<li>5. Construction of rooftop solar system.</li>

												<li>6. Obtain required approvals from local electricity utility.</li>

												<li>7. Install net-metering to get the system on the grid.</li>

												<li>8. The solar system is up and running.</li>
								      		</ul>
								     	</div>
								    </div>
								</div>
								<div class="card card3 animated zoomIn">
								    <div class="card-header  peach-gradient" id="headingTwo" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
								    	<h5 class="mb-0">
									        <button class="btn btn-link" type="button" >
									         What is Net Metering ?
									        </button>
									        <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
								    	<div class="card-body">
								       <p>Net metering is the process by which the solar energy generated can be seamlessly pushed into the main power grid. This is necessary to obtain the benefits of solar - zero / reduced electricity costs, and zero carbon footprint.</p>

										<p>This is the immediate effect of net metering on the customer’s electricity cost, and energy usage.</p>

										<p>In principle, net metering is a billing mechanism that credits solar energy system owners for the electricity they add to the grid. India does not support this yet.</p>

										<p>Right now, for a customer in India, net metering feeds solar energy into the main grid, reducing the usage of electricity from the utility company, and thus reducing the electricity bills.</p>
								      	</div>
								    </div>
								</div>
								<div class="card card4 animated zoomIn">
								    <div class="card-header  peach-gradient" id="headingThree" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
									    <h5 class="mb-0">
									        <button class="btn btn-link collapsed" type="button" >
									          How is net metering done? Does Solarmate help with this?
									        </button>
									         <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
								    	<div class="card-body">
								       <p> In order to get a net metering connection, the local utility company has to review and approve the solar project.</p>

										<p>Once that the project is approved, they provide an updated bi-directional meter which has to be fitted into the main grid. This new meter is able to calculate net metering, while observing the electricity flows from both the solar system and the electricity utility into the customer’s establishment.</p>

										<p>The time required for obtaining utility permissions is ever-evolving, and varies across states and regions:</p>

										<ul style="list-style-type: none;"><li>1. In Telangana and NCR, the utility permission phase is completed in 2-3 weeks.</li>

										<li>2. In Karnataka, it typically ranges from 4-6 weeks.</li>

										<li>3. In Maharashtra, it depends on the utility company and the city, and ranges between 2-6 weeks.</li></ul>

										<p>Solarmate helps customer through the application and review process with the local utility company, till the new bi-directional meter is installed.</p>
								        </div>
								    </div>
								</div>
								<div class="card card5 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingFour" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
									    <h5 class="mb-0">
									        <button class="btn btn-link collapsed" type="button" >
									         How long does the installation phase take?
									        </button>
									         <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
								    	<div class="card-body">
								    		<p>From the time of sales confirmation (advance payment), it usually takes 3-4 weeks for installation to start. The on-site construction / civil work phase is typically, 7 days for residential projects, and 1-2 months for larger commercial projects.</p>

											<p>The time required for obtaining utility permissions is ever-evolving, and varies across states and regions:</p>

											<ul style="list-style-type: none;">
												<li>1. In Karnataka, it typically ranges from 4-6 weeks.</li>

											<li>2. In Maharashtra, it depends on the utility company and the city, and ranges between 4-6 weeks.</li>

											<li>3. In Tamil Nadu, it generally takes 8 weeks.</li>
										  </ul>
								    	</div>

								    </div>
								</div>
								<div class="card card6 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingFive" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
									    <h5 class="mb-0">
									        <button class="btn btn-link collapsed" type="button" >
									         Can I install a solar system even if my locality has frequent power cuts?
									        </button>
									         <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
								    	<div class="card-body">
								    		<p>Yes, you can. In this case, you might need to go with an off-grid or a hybrid solar approach, where the battery - inverter systems continue to work as earlier with solar power added to the system.</p>

											<p>Please see the next FAQ for a more detailed view.</p>
								    	</div>


								    </div>
								</div>
								<div class="card card7 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingSix" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
									    <h5 class="mb-0">
									        <button class="btn btn-link collapsed" type="button" >
									         What is the difference between an on-grid solar system and an off-grid / hybrid solar system?
									        </button>
									         <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionExample">
								    	<div class="card-body">
								    		<div class="row">
								    			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								    				<div class="col-lg-6 col-md-6 col-sm-12 col-sm-12" style="float: left;">
								    					<div class="card animated zoomIn">
								    						<div class="card-header purple-gradient">
								    							On Grid Solar
								    						</div>
								    			
								    						<div class="card-body">
								    							Pros
																<ul style="list-style-type: none;"><li>
																Simple design, and low maintenance</li>

																<li>It can be easily integrated for net-metering.</li>

																<li>All appliances can work on it, since wiring does not need to change.</li></ul>
																<hr>
																Cons
																<ul style="list-style-type: none;"><li>Only works when grid power (reference line) available. In case of power cuts, solar electricity cannot be used, since it depends on a reference voltage from grid power.</li></ul>
																<hr>
																Best used for
																<ul style="list-style-type: none;"><li>An on-grid system is ideal when you would like to lower your electricity bills, and do not need power backup.</li></ul>
								    						</div>
								    					</div>
								    				</div>
								    				<div class="col-lg-6 col-md-6 col-sm-12 col-sm-12" style="float: left;">
								    					<div class="card animated zoomIn">
								    						<div class="card-header purple-gradient">
								    							Off-Grid or Hybrid Solar
								    						</div>
								    			
								    						<div class="card-body">
								    							Pros
																<ul style="list-style-type: none;"><li>
																In areas with unreliable power, people often have batteries and an inverter system for more steady electricity. Solar power can be added to charge batteries faster when grid-power is present, and to power appliances when it is not.</li></ul>
																<hr>
																Cons
																<ul style="list-style-type: none;"><li>Wiring for the solar system is separate, so typically only a few appliances are hooked up to use that electricity.</li>
																<li>
																	Batteries require maintenance and need to be changed every three or four years. Maintenance-free batteries are typically more expensive and so, less popular.
																</li>
																</ul>
																<hr>
																Best used for
																<ul style="list-style-type: none;"><li>An off-grid system is best suited if you have unreliable electricity and are looking to decrease disruption to your life due to that.</li></ul>
								    						</div>
								    					</div>
								    				</div>
								    			</div>
								    		</div>
								    	</div>

								    </div>
								</div>

								<div class="card card8 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingSeven" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
									    <h5 class="mb-0">
									        <button class="btn btn-link collapsed" type="button" >
									         Will the solar installation cause damage to the roof?
									        </button>
									         <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordionExample">
								    	<div class="card-body">
								    		<p>No. On an average, solar panels add only 1-2 kg of weight per square foot of roof area. All roofs are typically able to withstand significantly more weight than this.</p>

											<p>Also, when the Site Visit is done by an Solarmate representative, they will inspect the roof for robustness. In the unusual event of the roof not being able to support the weight of the solar system, they would be able to suggest reinforcement mechanisms that would make a rooftop system possible.</p>

											<p>Rooftop systems are very durable, and have an average lifetime of 25 years. During this period, if roof work ever has to be done, the rooftop system can be easily dismantled and reassembled. So, future roof work is always possible.</p>
								    	</div>

								    </div>
								</div>
								<div class="card card9 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingEight" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
									    <h5 class="mb-0">
									        <button class="btn btn-link collapsed" type="button" >
									         What are the differences between Economy and Premium installations?
									        </button>
									         <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-parent="#accordionExample">
								    	<div class="card-body">
								    		<div class="row">
								    			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								    				<div class="col-lg-6 col-md-6 col-sm-12 col-sm-12" style="float: left;">
								    					<div class="card animated zoomIn">
								    						<div class="card-header purple-gradient">
								    							Economy
								    						</div>
								    			
								    						<div class="card-body">
								    							<h6>These industry leading brands have manufacturing and field experience of over 5 years and their panels are well-regarded for their value-for-money performance.</h6>
								    							<br>
								    							<h4>Solar Panels :</h4>
								    							<div class="row">
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/economy/1.png" width="130" height="80"></div>
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/economy/2.jpg" width="130" height="80"></div>
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/economy/3.png" width="130" height="80"></div>
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/economy/4.jpg" width="130" height="80"></div>

								    							</div>
								    							<br>
								    							<h4>Inverters :</h4>
								    							<div class="row">
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/economy/5.jpg" width="130" height="80"></div>
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/economy/6.png" width="130" height="80"></div>
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/economy/7.jpg" width="130" height="80"></div>
								    							</div>
								    							<br>
								    							<h4>Mounting Structure
								    							</h4>
																<h6>Galvanized Iron. Roof mounted.</h6>
								    						</div>
								    					</div>
								    				</div>
								    				<div class="col-lg-6 col-md-6 col-sm-12 col-sm-12" style="float: left;">
								    					<div class="card animated zoomIn">
								    						<div class="card-header purple-gradient">
								    							Premium
								    						</div>
								    			
								    						<div class="card-body">
								    							<h6>
								    								These industry leading brands have manufacturing and field experience of over 10 years.
								    							</h6>
								    							<br>
								    							<h4>Solar Panels :</h4>
								    							<div class="row">
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/premium/1.png" width="130" height="80"></div>
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/premium/2.jpg" width="130" height="80"></div>
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/premium/3.png" width="130" height="80"></div>
								    							</div>
								    							<br>
								    							<h4>Inverters :</h4>
								    							<div class="row">
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/premium/4.jpg" width="130" height="80"></div>
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/premium/5.jpg" width="130" height="80"></div>
								    								<div class="col-lg-6 col-md-6 col-sm-6  col-xs-6" style="float: left;"><img src="images/premium/6.png" width="130" height="80"></div>
								    							</div>
								    							<br>
								    							<h4>Mounting Structure</h4>

																<h6>Galvanized Iron or premium Aluminium structures. Roof mounted.</h6>

								    						</div>
								    					</div>
								    				</div>
								    			</div>
								    		</div>

										</div>
								    </div>
								</div>

							</div>
					    </div>


						<div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
							<div class="accordion" id="accordionExample">
								<div class="card card10 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingNine" data-toggle="collapse" data-target="#collapseNine" aria-expanded="true" aria-controls="collapseNine">
								    	<h5 class="mb-0">
									        <button class="btn btn-link" type="button" >
									        Does Solarmate help with obtaining solar loans?
									        </button>
									        <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordionExample">
								    	<div class="card-body">
								      		<p>Yes, Solarmate helps customers with getting solar loans.</p>
								      		<p>For residential projects, Solarmate facilitates customers get EMI-based term loans, and this facilitation fee is included in the cost of the project.</p>
								      		<p>For commercial and industrial projects, both loans and OpEx/PPA financing might be available depending on the project size and customer profile.</p>
											   
								     	</div>
								    </div>
								</div>
								<div class="card card11 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingTen" data-toggle="collapse" data-target="#collapseTen" aria-expanded="true" aria-controls="collapseTen">
								    	<h5 class="mb-0">
									        <button class="btn btn-link" type="button" >
									         What are the terms and conditions for solar loans?
									        </button>
									        <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-parent="#accordionExample">
								    	<div class="card-body">
								      		<ul style="list-style-type: none;">
								      			<h4>For Individuals</h4>
												<li>Loan Amount Limits</li>

												<li>Up to ₹25 Lakh or 85% of project cost (whichever is lower)</li>

												<h5>Interest Rate</h5>

												<li>Home loan top up: ~9%</li>

												<li>General: 10.65%</li>

												<li>Women: 10.15%</li>
												<hr>
												<h4>For Commercial Sites, Factories, Colleges or Hospitals</h4>
												
												<h5>Loan Amount Limits</h5>

												<li>Up to ₹1.5 Crore or 80% of project cost (whichever is lower)</li>

												<h5>Interest Rate</h5>

												<li>Upto ₹25 Lakh: 10.65%</li>

												<li>More than ₹25 Lakh: starting at 9.5%</li>
												<hr>
												<h4>For Housing Societies</h4>
												<h5>Loan Amount Limits</h5>

												<li>Up to ₹1.5 Crore or 80% of project cost (whichever is lower)</li>

												<h5>Interest Rate</h5>

												<li>General: 10.65%</li>
												<hr>
												<h4>For all categories</h4>
												
												<h5>Loan duration</h5>

												<li>Up to 7 years</li>

												<h5>Loan processing time needed</h5>

												<li>Typically 3-4 weeks</li>

												<h5>Loan processing charges</h5>

												<li>Up to ₹1 Lakh: Free!</li>

												<li>Above ₹1 Lakh: From 0.50% of loan amount</li>

												<h5>Insurance Requirements</h5>

												<li>Solar assets created with such bank loans need to be insured in favour of the bank for the duration of the loan</li>
								      		</ul>
								     	</div>
								    </div>
								</div>	

								<div class="card card12 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingEleven" data-toggle="collapse" data-target="#collapseEleven" aria-expanded="true" aria-controls="collapseEleven">
								    	<h5 class="mb-0">
									        <button class="btn btn-link" type="button" >
									        What is the process for a solar loan application?
									        </button>
									        <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseEleven" class="collapse" aria-labelledby="headingEleven" data-parent="#accordionExample">
								    	<div class="card-body">
								      		<p>At the time of the site visit, please provide the following documents:<p>

								      		<ul style="list-style-type: none;">
								      			<li>1. PAN Card</li>

												<li>2. Proof of Identity</li>

												<li>3. Proof of Address</li></ul>

												
								      		</ul>
								      		<p>We will match your requirements across our bank and lender partners to find the best loan for you, guide you through the KYC process, and facilitate the approval process so your installation work can start at the earliest.</p>
								     	</div>
								    </div>
								</div>	
								<div class="card card13 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingTwelve" data-toggle="collapse" data-target="#collapseTwelve" aria-expanded="true" aria-controls="collapseTwelve">
								    	<h5 class="mb-0">
									        <button class="btn btn-link" type="button" >
									        Can my solar system be installed while loan approval is in process?
									        </button>
									        <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseTwelve" class="collapse" aria-labelledby="headingTwelve" data-parent="#accordionExample">
								    	<div class="card-body">
								      		
								      		<p>	Yes, as long as the quality of the components and project is feasible, banks can process the loan in parallel to the installation.</p>

                                               <p> There are other activities that can be done while the loan is being processed. In most states, a permission is needed from the local utility before installation can begin; this can be done while the loan is being approved.</p>
								      	
								     	</div>
								    </div>
								</div>	

								<div class="card card14 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingTherteen" data-toggle="collapse" data-target="#collapseTherteen" aria-expanded="true" aria-controls="collapseTherteen">
								    	<h5 class="mb-0">
									        <button class="btn btn-link" type="button" >
									        What are the available subsidies?
									        </button>
									        <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseTherteen" class="collapse" aria-labelledby="headingTherteen" data-parent="#accordionExample">
								    	<div class="card-body">
								      		<p>The Central and many state governments have announced tax benefits and subsidies to promote solar energy.</p>

											<p>Currently, consumer could be eligible upto 30% subsidy from central government. Approval of subsidy comes with mandate of using MNRE approved Indian and/or value segment panel and inverters with limited quality options. In addition, subsidy approval and disbursement process is opaque, frictionful and requires extensive paper work.</p>

											<p>Most of our customer have been unable to get the subsidy. At the current low prices, the subsidy only compromises the long term system quality and the customer ownership experience.</p>

											<p><b>Residential end consumers:</b> In an effort to help our customer with highest and varied quality options, timely and transparent solar buying experience, we are unable to support subsidy.</p>

											<p><b>Commercial consumers:</b>Subsidy is not applicable.</p>
											<p>Accelerated Depreciation (AD) related tax benefits are applicable and we will be happy assist with the processes.</p>
								     	</div>
								    </div>
								</div>

							</div>
						</div>
						
						<div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
							<div class="accordion" id="accordionExample">
								<div class="card card15 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingFourteen" data-toggle="collapse" data-target="#collapseFourteen" aria-expanded="true" aria-controls="collapseFourteen">
								    	<h5 class="mb-0">
									        <button class="btn btn-link" type="button" >
									       What do I need to do to maintain the system in good condition?
									        </button>
									        <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseFourteen" class="collapse" aria-labelledby="headingFourteen" data-parent="#accordionExample">
								    	<div class="card-body">
								      		<p>You don’t need to do much to maintain the system in good condition.</p>

											<p>The solar system uses Photovoltaic (PV) cells, which are very robust and low-maintenance.</p>

											<p>We recommend a monthly cleaning of the panels.</p>

											<p>Other than that for any issues, you can reach out to Solarmate directly through the mobile app.</p>
											   
								     	</div>
								    </div>
								</div>
								<div class="card card16 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingFifteen" data-toggle="collapse" data-target="#collapseFifteen" aria-expanded="true" aria-controls="collapseFifteen">
								    	<h5 class="mb-0">
									        <button class="btn btn-link" type="button" >
									       How does the Solarmate mobile app help me?
									        </button>
									        <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseFifteen" class="collapse" aria-labelledby="headingFifteen" data-parent="#accordionExample">
								    	<div class="card-body">
								      		<p>The Solarmate mobile app is the one-stop touchpoint for all things solar, post-installation. It enables the following actions for the customer:</p>

											<ul style="list-style-type: none;">
												<li>1. Regular and real-time tracking of solar energy generation.</li>

												<li>2. View into the savings provided by switching to solar.</li>

												<li>3. System details are available on the app for easy access.</li>

												<li>4. One-click support through the app for any service requests.</li>

												<li>5. Easy to share impact and savings with friends and family.</li>

												<li>6. Referral program with referral bonuses and tonnes of goodwill.</li>
											</ul>
								     	</div>
								    </div>
								</div>
								<div class="card card17 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingSixteen" data-toggle="collapse" data-target="#collapseSixteen" aria-expanded="true" aria-controls="collapseSixteen">
								    	<h5 class="mb-0">
									        <button class="btn btn-link" type="button" >
									       What are the warranties on the system?
									        </button>
									        <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseSixteen" class="collapse" aria-labelledby="headingSixteen" data-parent="#accordionExample">
								    	<div class="card-body">
								      		<h5>Solar Panel:</h5>
											<ul style="list-style-type: none;">
												<li>10 year manufacturing defect warranty by manufacturer.</li>

												<li>25 year performance warranty.</li>

												<li>Less than 1% annual degradation in line with international standards.</li>

												<li>MNRE and International Standards Certified.</li>
											</ul>
											<hr>
											<h5>Inverter:</h5>
											<ul style="list-style-type: none;">
												<li>5 year warranty by manufacturer.</li>

												<li>MNRE and International Standards Certified.</li>
											</ul>
											<hr>
											<h5>Mounting Structure:</h5>
											<ul style="list-style-type: none;">
												<li>80-micron Galvanized Iron or Aluminum. Designed for 150kmph wind speeds and more than 5 years of structural integrity.</li>
											</ul>
											<hr>
											<h5>Free 2 year maintenance is included with all Solarmate systems:</h5>
											<ul style="list-style-type: none;">
												<li>Free data for Solarmate monitoring device, with information displayed on the Solarmate app.</li>

												<li>Contact Solarmate Support directly from the Solarmate app itself.</li>

												<li>Alerts and notifications about system maintenance on the app.</li>

												<li>Onsite troubleshooting.</li>

												<li>Replacement of any part of the system, caused by design or structural.</li>

												<li>Excluded: Routine washing and cleaning of panels is to be done by the customer.</li>
											</ul>
								     	</div>
								    </div>
								</div>
								<div class="card card18 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingSeventeen" data-toggle="collapse" data-target="#collapseSeventeen" aria-expanded="true" aria-controls="collapseSeventeen">
								    	<h5 class="mb-0">
									        <button class="btn btn-link" type="button" >
									       Does Solarmate provide annual maintenance contract(s)?
									        </button>
									        <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseSeventeen" class="collapse" aria-labelledby="headingSeventeen" data-parent="#accordionExample">
								    	<div class="card-body">
								      		<p>Solarmate provides a free 2-year annual maintenance package to all customers.</p>

											<p>The package includes:</p>
											<ul style="list-style-type: none;">
												<li>1. Solarmate App access and maintenance alerts.</li>

												<li>2. 48-hour response time on all support / service calls.</li>

												<li>3. Troubleshooting for all issues.</li>

												<li>4. Repair of all malfunctions (not including costs of parts).</li>

												<li>5. The maintenance package can be extended at any point beyond 2 years, by paying a minimal fee.</li>
											</ul>
											   
								     	</div>
								    </div>
								</div>
								<div class="card card19 animated zoomIn">
								    <div class="card-header peach-gradient" id="headingEighteen" data-toggle="collapse" data-target="#collapseEighteen" aria-expanded="true" aria-controls="collapseEighteen">
								    	<h5 class="mb-0">
									        <button class="btn btn-link" type="button" >
									       Do I need to buy insurance for solar system?
									        </button>
									        <i class="fa fa-angle-down" style="float: right;" ></i>
								        </h5>
								    </div>
								    <div id="collapseEighteen" class="collapse" aria-labelledby="headingEighteen" data-parent="#accordionExample">
								    	<div class="card-body">
								      		<p>We would recommend you to do it. Think of the solar installation as analogous to buying a car; just like you would buy insurance for your car, we suggest you do the same for the solar installation.</p>

											<p>In the case of systems purchased through bank solar loans, the bank would require insurance to be in place for the duration of the loan term.</p>
											   
								     	</div>
								    </div>
								</div>

							</div>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<?php
				include_once('footer.php');
			?>
		</div>
	</div>
</div>
<script type="text/javascript">
	new WOW().init();
</script>