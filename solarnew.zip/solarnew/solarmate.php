<?php
		$host="localhost";
		$username="root";
		$password="BNag18@123";
		$dbname="solarmate";


		$conn=mysqli_connect($host,$username,$password,$dbname);

		if(!$conn){
			die("connection failed=".mysqli_connect_error());
		}else{
			//echo "Database connection successfull";
		}

?>