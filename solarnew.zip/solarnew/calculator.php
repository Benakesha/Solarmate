<?php
	
	include_once('navigation.php');

?>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">							
<link rel="stylesheet" type="text/css" href="css/calculator.css">


<div class="container-fluid" style="margin-top: 8%;">
	<div class="row">
		<div class="col-md-12">
			<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="float: left;"> 
				<div class="card card1">
					<div class="card-body">
						<h4>Find Location <i class="fa fa-map-marker" style="margin-left: 3%;"></i></h4>
						<form oninput="return validatePin(this);" >
							<div class="md-form ">
								<input type="text" name="pincode" id="pincode" class="form-control" maxlength="6">
								<label for="pincode">PIN CODE <span style="color: red;">*</span></label>
								<div style="color: red;" id="pinError"></div>
							</div>
							
							<div class="md-form">
								<button type="submit" class="btn btn-warning waves-effect" id="design" name="design"  >FIND LOCATION</button>
							</div>


						</form >
						
					</div>
				</div>
			</div>
			<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12" style="float: left; display: none;" id="div2">
				<div class="card card2">
					<div class="card-body">
						<h4 id="title">Let's Design Your System&nbsp;&nbsp;&nbsp;<img src="images/sun.png" width="50" height="50"></h4>
						<form >
							<div id="d1" class="col-lg-5 col-md-5 col-sm-8 col-xs-8" style="float: left;">
								<div>
									<label for="pincode">Pin Code </label>
									<input type="text" name="pincodess" id="pincodess" class="form-control" maxlength="6" value="" disabled="true">
								</div>
							</div>
							<div id="d2" class="col-lg-6 col-md-6 col-sm-8 col-xs-8" style="float: left;">
								<div>
									<label for="state">State </label>
									<input type="text" name="state" id="state" class="form-control" 	value="" disabled="true" >
								</div>
							</div>
							<div id="d3" class="col-lg-5 col-md-5 col-sm-8 col-xs-8" style="float: left;">
							<div>
								<label for="district">District </label>
								<input type="text" name="district" id="district" class="form-control" value="" disabled="true">
							</div>
							</div>
							<div id="d4" class="col-lg-6 col-md-6 col-sm-8 col-xs-8" style="float: left;">
							<div >
								<label for="citys">Choose City <span style="color: red;">*</span></label>
								 <select class="form-control" id="citys">
								  
								</select> 
							</div>
							</div>
							<div id="d5" class="col-lg-5 col-md-5 col-sm-8 col-xs-8" style="float: left;">
							<div >
								<label for="etype">Electricity Connection Type <span style="color: red;">*</span></label>
								<select for="etype" class="form-control">
									<option selected="true" disabled="true">Choose One</option>
									<option value="1">Residential</option>
									<option value="2">Commercial</option>
									<option value="3">Housing Society</option>
								</select>								
							</div>
							</div>
							<div id="d6" class="col-lg-6 col-md-6 col-sm-8 col-xs-8" style="float: left;">
								<div>
									<label for="area">Roof Area(sqft) <span style="color: red;">*</span></label>
									<input type="text" name="area" id="area" class="form-control">
									<div style="color: red;text-align: right;font-size: 12px;">Roof area should be greater than 100 sqft</div>
								</div>
							</div>
							<div id="d7" class="col-lg-5 col-md-5 col-sm-8 col-xs-8" style="float: left;">
								<div>
									<label for="bill">Average Monthly Electricity Bill (Rs) <span style="color: red;">*</span></label>
									<input type="text" name="bill" id="bill" class="form-control">
									<div style="color: red;text-align: right;font-size: 12px;">Monthly bill should be greater than 100 Rs.</div>
								</div>
							</div>
							<div id="d8" class="col-lg-6 col-md-6 col-sm-8 col-xs-8" style="float: left;">
							<div>
								<label for="eprovider">Electricity Provider <span style="color: red;">*</span></label>
								<select for="eprovider" class="form-control">
									<option selected="true" disabled="true">Choose One</option>
									<option value="4">MESCOM</option>
									<option value="5">BESCOM</option>
									<option value="6">HESCOM</option>
									<option value="7">GESCOM</option>
									<option value="8">CESCOM</option>
								</select>								
							</div>
							</div>
							<div id="d9" class="col-lg-8 col-md-8 col-sm-8 col-xs-8" style="float: left;">
								<div class="md-form">
									<button type="submit" class="btn btn-warning waves-effect btn-lg" id="design1" name="design1">Design your price</button>
								</div>
							</div>	
						</form>
					</div> 
				</div>
			</div>
		</div>
		<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12" id="div4" style="display: none;">
			<div class="card">
				<div class="card-body">
					<div><i class="fa fa-map-marker"></i><span id="place"></span></div>
				</div>
			</div>
		</div>

	</div>
</div>
<div class="container-fluid" style="margin-top: 5%;">
	<div class="row">
		<div class="col-md-12">
			<?php
				include_once('footer.php');
			?>
		</div>
	</div>
</div>

<script type="text/javascript">
	
	function validatePin(form){

		if(form.pincode.value == ''){
			document.getElementById('pinError').innerHTML="Please enter pincode";
			return false;
			$('#pincode').focus();
		}else{
			if(form.pincode.value.length < 6){
				document.getElementById('pinError').innerHTML="Pincode should contain 6 digit";
				return false;
				$('#pincode').focus();
			}else{
				var reg=/^\d+$/;
				var pins=form.pincode.value;
				if(!pins.match(reg)){
					document.getElementById('pinError').innerHTML="Pincode should contain only number";
					return false;
					$('#pincode').focus();
				}else{
					document.getElementById('pinError').innerHTML="";
				} 

			}
		}
	}

	
	$('#pincode').on('keyup',function(){
		$('#div2,#div4').hide();

	});

	$('#design').on('click',function(e){
		e.preventDefault();
		
		$.ajax({ 
			
			url: '/solarNew/findPincode.php',
			type: 'POST',
		 	dataType: 'json',
			
		 	data:{ 	pin: $('#pincode').val() },
		 
		 }).done(function(response){
		 		if(response.status == 'success'){
		 			$('#div2').show();
			 	 	var options=$('#citys');
		            $('#pincodess').val(response.pin);
		            $('#state').val(response.sname);
		            $('#district').val(response.dname);
		           
		            var valuess=response.cname;
		            $('#citys').empty();
		            for(var i=0; i < valuess.length; i++){
			           	var id=i;
		            	var name=response.cname;
		          	 	$("#citys").append("<option value='"+id+"'>"+ valuess[i]+"</option>");
	           	 }

		 		}else if(response.status == 'error'){
		 			document.getElementById('pinError').innerHTML="Pincode not found";
		 		}
		 	
    	});

	});


	$('#design1').on('click',function(e){
		e.preventDefault();

		$('#div4').show();



		//$('#place').text($('#district').val());



	});

	


	
</script>