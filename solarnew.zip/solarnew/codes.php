<?php 


    php -q /home/enermate/public_html/monitor/monitor/INPUT1.php >/dev/null 2>&1  (2 hr)


    php -q /home/enermate/public_html/crons/recipharmaOSU.php >/dev/null 2>&1



    php -q /home/enermate/public_html/crons/recipharmaSSU.php >/dev/null 2>&1






create table solarmate.states (
    stateCode varchar(100),
    stateName varchar(100),
    SId int(11) AUTO_INCREMENT PRIMARY KEY 
   
);

CREATE TABLE solarmate.district(
    stateCode int(100),
    districtName varchar(100),
    pincode int(50),
    DId INT(11) AUTO_INCREMENT primary KEY,
    FOREIGN KEY (stateCode) REFERENCES states (SId)
);

CREATE TABLE solarmate.city(
    districtCode int(100),
    cityName varchar(100),
    pincode int(50),
    CId INT(11) AUTO_INCREMENT primary KEY,
    FOREIGN KEY (districtCode) REFERENCES district (DId)
);
