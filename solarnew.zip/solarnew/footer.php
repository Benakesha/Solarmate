<footer style="margin-left: -30px;margin-right: -30px;padding-left: 0px;padding-right: 0px;margin-top: 5%;" class="page-footer font-small unique-color-dark">

        <div style="background-color: #00BCD4">
          <div class="container">
           <div class="row py-4 d-flex align-items-center">
              <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
              <!--  <h6 class="mb-0">Get connected with us on social networks!</h6> -->
              </div>
        
              <!--<div class="col-md-6 col-lg-7 text-center text-md-right">
                <a class="fb-ic" href="http://www.facebook.com">
                  <i class="fa fa-facebook white-text mr-4"> </i>
                </a>
                <a class="tw-ic" href="http://www.twitter.com">
                  <i class="fa fa-twitter white-text mr-4"> </i>
                </a>
              
                <a class="gplus-ic" href="http://www.googleplus.com">
                  <i class="fa fa-google-plus white-text mr-4"> </i>
                </a>
             
                <a class="li-ic" href="http://www.linedin.com">
                  <i class="fa fa-linkedin white-text mr-4"> </i>
                </a>
              
                <a class="ins-ic" href="http://www.instagram.com">
                  <i class="fa fa-instagram white-text"> </i>
                </a>

              </div> -->
          
            </div>  
          
          </div>
        </div>

        <div class="container text-center text-md-left mt-5">

          <div class="row mt-3">
  
            <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

              <h6 class="text-uppercase font-weight-bold">Solarmate</h6>
              <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
              <p><img src="images/logo.jpg" width="200" height="150"></p>

            </div>
           
            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

              <h6 class="text-uppercase font-weight-bold">Services</h6>
              <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
              <p>
                <a href="index.php#firstDiv">Easy Financing</a>
              </p>
              <p>
               <a href="index.php#secondDiv">Loan Term</a>
              </p>
              <p>
               <a href="index.php#thirdDiv">Loan Process</a>
              </p>
              <p>
                <a href="index.php#fourthDiv">Installation Process</a>
              </p>
                        
            </div>
            
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

              <h6 class="text-uppercase font-weight-bold">Contact</h6>
              <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
              <p>
                <i class="fa fa-home mr-3"></i>Solarmate Service Pvt. Ltd.</p>  
              <p>
                <i class="fa fa-map-marker mr-3"></i> Bangalore, India</p>
              <p>
                <i class="fa fa-envelope mr-3"></i> solarmate@gmail.com</p>
              <p>
                <i class="fa fa-phone mr-3 fa-rotate-60"></i> + 91 94495 53545</p>
             
            </div>
         
          </div>
        
        </div>
        
        <div class="footer-copyright text-center py-3">© 2018 Copyright:
          <a href="https://mdbootstrap.com/bootstrap-tutorial/"> Solarmate Service Pvt. Ltd.</a>
        </div>
      
      </footer>

<script type="text/javascript">
  new WOW().init();
</script>