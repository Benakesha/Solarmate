<?php
if(isset( $_POST['username']))
  $username = $_POST['username'];
if(isset( $_POST['email']))
  $email = $_POST['email'];
if(isset( $_POST['message']))
  $message = $_POST['message'];
if(isset( $_POST['subject']))
  $subject = $_POST['subject'];
/*

  $curl = curl_init();
  curl_setopt($curl, CURLOPT_POST, 1);
  curl_setopt($curl, CURLOPT_URL,'http://enermate.in/EmailService/sendRecipharmaOSUDailyReport.php');  
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  
  // Insert the data
  //curl_setopt($curl, CURLOPT_POSTFIELDS, $some_data);

  $result = curl_exec($curl);
   curl_close($curl);

  echo $result;*/
  

?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">

    let username = '<?php echo $username;?>',
        email= '<?php echo $email;?>',
        subject= '<?php echo $subject;?>',
        message= '<?php echo $message;?>';

     $.ajax({
            type : 'POST', 
            url  : ,//'./EmailService/contact_us_mail.php', 
            data : { name:username, emails:email, sub:subject, msg:message}, 
            success: function(response){
            <?php 
            header("location:/solar/Contact.php?msg=hai");
            ?>
            } 
      });

</script>