<?php
	
	include_once('navigation.php');

?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<style type="text/css">
	#refresh{
		color:orange;
		font-size: 40px;
		margin-top: 5px;
		margin-left: 20px;
		
	}
	#captch{
		width: 80%;
		margin-left:60px; 
		font-size: 20px;
	}
	#sendMessage{
		font-size: 20px;
		padding-bottom: 50px;
		width: 60%;
		margin-left: 18%;
		margin-top: 2%;
	}

	#nameError,#emailError,#subjectError,#messageError,#captchaError{
		color: red;
	}
</style>
<script type="text/javascript">
	
$(function(){
	getCaptcha();
});
function getCaptcha() {
    var chars = "0Aa1Bb2Cc3Dd4Ee5Ff6Gg7Hh8Ii9Jj0Kk1Ll2Mm3Nn4Oo5Pp6Qq7Rr8Ss9Tt0Uu1Vv2Ww3Xx4Yy5Zz";
    var string_length = 5;
    var captchastring = '';
    for (var i=0; i<string_length; i++) {
        var rnum = Math.floor(Math.random() * chars.length);
        captchastring += chars.substring(rnum,rnum+1);
    }

   document.getElementById("captch").innerHTML = captchastring;
}

</script>

<div class="container" style="margin-bottom: 3%;margin-top: 10%;">
	<div class="row">
		<div class="col-md-10 offset-md-1 ">
			<div class="card">
				<div class="card-body" style="margin-bottom: 3%;">
					      <!--Section: Contact v.2-->
					<section class="section" >
					    <!--Section heading-->
		   				<h4 style="text-align: center;font-weight: bold;text-decoration: underline;color: #00BCD4;padding-bottom: 40px;margin-top: 40px;">WE WOULD LIKE TO HEAR FROM YOU
			            </h4>
			            <div id="success" style="color: #00BCD4;text-align: center;font-size: 25px;">
			           	<?php
			           		if(isset($_GET['msg']) == "hai"){
			           			echo "Email sent successfuly";
			           		}
			           	?>
			           </div>
			            <!-- form -->
			            <div class="col-md-10 offset-md-1" style="float: left;">
			            	<form id="contactForm" name="contactForm" action="contact_mail.php" method="POST" onsubmit="return validateForm(this)" >
			            		<div class="row">
			            			<div class="col-md-6">
			            				<div class="md-form">
			            					<input type="text" name="username" id="username" class="form-control">
			            					<label for="username">Your Name <span style="color: red;">*</span></label>
			            				</div>
			            				<div id="nameError">           					
			            				</div>
			            			</div>
			            			<div class="col-md-6">
			            				<div class="md-form">
			            					<input type="text" name="email" id="email" class="form-control">
			            					<label for="email">Your Email <span style="color: red;">*</span></label>
			            				</div>
			            				<div id="emailError">           					
			            				</div>
			            			</div>	
			            		</div>
			            		<div class="row">
			            			<div class="col-md-12">
			            				<div class="md-form">
			            					<input type="text" name="subject" id="subject" class="form-control">
			            					<label for="subject">Subject <span style="color: red;">*</span></label>
			            				</div>
			            				<div id="subjectError">           					
			            				</div>
			            			</div>
			            		</div> 
			            		<div class="row">
			            			<div class="col-md-12">
			            				<div class="md-form">
			            					<textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea"></textarea>
			            					<label for="message">Your Message <span style="color: red;">*</span></label>
			            				</div>
			            				<div id="messageError">           					
			            				</div>
			            			</div>
			            		</div> 

			            		<div class="row">
			            			<div class="col-md-6">
			            				<div class="md-form">
			            					<input type="text" name="captchText" id="captchText" class="form-control">
			            					<label for="captchText">Enter Captch <span style="color: red;">*</span></label>
			            				</div>
			            				<div id="captchaError">           					
			            				</div>
			            			</div>
			            			<div class="col-md-4">
			            				<div class="md-form">
			            					<a class="btn btn-outline-info waves-effect" id="captch" name="captch"></a>
			            				</div>
			            			</div>
			            			<div class="col-md-2 refresher">
			            				<div class="md-form">
			            					<a id="refresh"><i class="fas fa-sync-alt"></i></a>
			            				</div>
			            			</div>
			            		</div>
			            		<div class="text-center text-md-left">
		              				<button type="submit" name="sendMessage" id="sendMessage" class="btn btn-danger form-control" >Send</button>
		            			</div>
			            	</form>

			            </div>
		      		<!--<div class="col-md-4" style="float: left;margin-top: 6%;padding-left: 6%;">
				   	        <ul class="list-unstyled">
				                <li><i class="fa fa-home" style="color: #00BCD4;font-size: 20px;"></i>
				                   &nbsp;&nbsp;EnerMate Energy Service Pvt. Ltd.
				                </li>

				                <li><i class="fa fa-map-marker mt-4" style="color: orange;font-size: 20px;"></i>
				                   &nbsp;&nbsp;Bangalore, India
				                </li>

				                <li><i class="fa fa-phone mt-4 " style="color: blue;font-size: 20px;"></i>
				                    &nbsp;&nbsp;+ 91 94495 53545
				                </li>

				                <li><i class="fa fa-envelope mt-4 " style="color: #00BCD4;font-size: 20px;"></i>
				                    &nbsp;&nbsp;enermatenergy@gmail.com<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;contact@enermate.in
				                </li>
			            	</ul>
			            </div>  -->
		        


			</section>
		<!--Section: Contact v.2-->
				</div>
			</div>
      
		</div>
	</div>
</div>
<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 ">
				<?php
					include_once('footer.php');
				?>
			</div>
		</div>
	</div>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
		
	$("#refresh").on('click',function(e){
			getCaptcha();
			document.getElementById('captchaError').innerHTML = "";	
	});

  	function validateForm(form){
  		
  		if(form.username.value == ''){
  			document.getElementById('nameError').innerHTML = "Name cannot be empty";
	        $('#username').focus();
	        return false;
  		}else{
  			if(form.username.value.length < 3){
	  			document.getElementById('nameError').innerHTML = "Name should be atleast 3 character";
		        $('#username').focus();
		        return false;
  			}else{
  				document.getElementById('nameError').innerHTML = "";	
  			}
  			
  		}

  		if(form.email.value == ''){
  			document.getElementById('emailError').innerHTML = "Email cannot be empty";
	        $('#email').focus();
	        return false;
  		}else{
  			var re = /^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@(([0-9a-zA-Z])+([-\w]*[0-9a-zA-Z])*\.)+[a-zA-Z]{2,9})$/;
	      	if(!re.test(form.email.value)){
	        	document.getElementById('emailError').innerHTML = "Email format invalid";
	          	$('#email').focus();
	          	return false;
	      	}else{
	      		document.getElementById('emailError').innerHTML = "";	
	      	}
  		}

  		if(form.subject.value == ''){
  			document.getElementById('subjectError').innerHTML = "Subject cannot be empty";
	      	$('#subject').focus();
	      	return false;
  		}else{
  			document.getElementById('subjectError').innerHTML = "";	
  		}

  		if (form.message.value == "") {
	      document.getElementById('messageError').innerHTML = "Message cannot be empty";
	      $('#message').focus();
	      return false;
	  	}else{
	  		document.getElementById('messageError').innerHTML = "";	
	  	}

	  	if(form.captchText.value == ''){
	  		document.getElementById('captchaError').innerHTML = "Message cannot be empty";
	        $('#captchText').focus();
	        return false;
	  	}else{
	  		var captchValue=document.getElementById('captch').text;
	  		captchValue=captchValue.toString();
	  		captchValue=captchValue.toUpperCase();

	  		var captchInput=document.getElementById('captchText').value;
	  	//	captchInput=captchInput;

	  		console.log("captchInput="+captchInput);
	  		console.log("captchValue="+captchValue);
	  		
	  		if(captchInput != captchValue){
	  			document.getElementById('captchaError').innerHTML = "Captcha string not matched";
	  			$('#captchText').focus();
	  			return false;

	  		}else{
	  			document.getElementById('captchaError').innerHTML = "";	
	  		}
	  		
	  	}
		  		 
	  	 
	  }
setTimeout(function() {

    $('#success').fadeOut('fast');
	
	}, 3000); 
</script>

