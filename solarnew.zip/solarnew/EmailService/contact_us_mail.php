<?php

$ROOT_PATH = $_SERVER["DOCUMENT_ROOT"] . "/enermatein/EmailService";
include_once($ROOT_PATH.'/common_functions.php');

$fullName =$_POST['name'];
$fromEmail =$_POST['emails'];
$toEmail = "benakeshnagaraj@gmail.com";
$subject = $_POST['sub'];
$message = $_POST['msg'];
$emailService = new EnermateEmailService();
$emailService->sendContactMail($fromEmail, $fullName, $toEmail, $subject, $message);

?>