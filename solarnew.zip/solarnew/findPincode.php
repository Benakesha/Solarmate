
<?php
		 	include 'solarmate.php';
   			$cityNames=array();
	 
	   		$pincode=$_POST['pin'];
			$pincode=stripcslashes($pincode);
			$pincode=mysqli_real_escape_string($conn,$pincode);
			
			$sql="SELECT c.*,d.*,s.* FROM city c,district d,states s WHERE s.SId=d.stateCode AND d.DId=c.districtCode AND c.pincode=$pincode";
			
			$res=mysqli_query($conn,$sql);
			$count=mysqli_num_rows($res);
								
			if($count>0){
			//	$i=0;
				while ($row=mysqli_fetch_assoc($res)) {
					$stateName=$row['stateName'];
					$stateCode=$row['stateCode'];
					$districtName=$row['districtName'];
					$cityName=$row['cityName'];
					$pincodes=$row['pincode'];
					$cityNames[]=$cityName;
					//$i++;
				}
				echo json_encode(array("cname"=>$cityNames,"sname"=>$stateName,"dname"=>$districtName,"pin"=>$pincodes,"status"=>'success'));

			}else{
				echo json_encode(array("status"=>'error'));
			}
	
?>
